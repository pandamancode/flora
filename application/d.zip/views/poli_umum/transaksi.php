
<div class="box box-primary">
    <div class="panel-heading">
      <i class='fa fa-user fa-fw'></i> Petugas
      <a href="javascript:;" class="btn-petugas pull-right"><i class="fa fa-plus-circle fa-fw"></i> Tambah&nbsp;</a>
    </div>

	<div class="box box-body">
	    <div class="table-responsive">
			<table class="table table-hover table-stripped" id="table">
				<thead class="table-header">
					<tr>
						<th width="5%">No.</th>
						<th>Petugas</th>
						<th>Divisi</th>
						<th width="5%">Aksi</th>
					</tr>
				</thead>
				<tbody>
					<?php
					if($petugas->num_rows()>0){
					$no=0;foreach($petugas->result() as $p){ $no++; ?>
					<tr>
						<td><?=$no?></td>
						<td><?=$p->nama_petugas?></td>
						<td><?=$p->status?></td>
						<td><a href="<?=base_url()?>pelayanan/hapus_petugas/<?=$p->id_petugas_pelayanan?>" class="btn btn-danger btn-xs"><i class="fa fa-trash"></i></a></td>
					</tr>
					<?php } }else{ echo "<tr><td colspan='6'><em>Tidak Ada Data</em></td></tr>"; } ?>
				</tbody>
			</table>
		</div>
	</div>
</div>
