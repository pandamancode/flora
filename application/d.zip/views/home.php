<div class='row'>
    <div class='col-md-12'>
        <div class="box box-warning" id="mn_trx">        
            <div class="box-body text-center">
                <h2 style="color: orange;"><strong>Klinik Flora</strong></h2>
                <h4>Jl. Pagar Alam, Segala Mider, Kec. Tj. Karang Barat, Kota Bandar Lampung, Lampung 35132</h4>
                <h4>Telp. 0812-7254-3359</h4>
            </div>
        </div>
    </div>
</div>

<script type="text/javascript">
	$('#m_home').addClass('active');
</script>