<header class="main-header">
  <nav class="navbar navbar-static-top">
    <div class="container-fluid">
    <div class="navbar-header">
      <a href="javascript:;" class="navbar-brand"><b>Kalo </b> Klinik</a>
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar-collapse">
        <i class="fa fa-bars"></i>
      </button>
    </div>
    
    <div class="collapse navbar-collapse" id="navbar-collapse">
      <ul class="nav navbar-nav">
        <li id="m_home"><a href="<?=base_url()?>home"><i class="fa fa-home"></i> Home</a></li>

        <li class="dropdown" id="m_master">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-bookmark"></i> Master Data <span class="caret"></span></a>
          <ul class="dropdown-menu" role="menu">
            <li id="m_pasien"><a href="<?=base_url()?>pasien"><i class="fa fa-user"></i> Pasien</a></li>
            <li id="m_petugas"><a href="<?=base_url()?>petugas"><i class="fa fa-user-md"></i> Petugas</a></li>
            <li id="m_obat"><a href="<?=base_url()?>obat"><i class="fa fa-tag"></i> Obat</a></li>
            <li id="m_diagnosa"><a href="<?=base_url()?>penyakit"><i class="fa fa-stethoscope"></i> Diagnosa</a></li>
          </ul>
        </li>

        <li id="m_registrasi"><a href="<?=base_url()?>Pendaftaran"><i class="fa fa-edit"></i> Registrasi</a></li>

        <li class="dropdown" id="m_poli">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-bank"></i> Poliklinik <span class="caret"></span></a>
          <ul class="dropdown-menu" role="menu">
            <li id="m_poliumum"><a href="<?=base_url()?>poli_umum"><i class="fa fa-stethoscope"></i> Poli Umum</a></li>
            <li id="m_poligigi"><a href="<?=base_url()?>home"><i class="fa fa-stethoscope"></i> Poli Gigi</a></li>
          </ul>
        </li>

        <li id="m_ekg"><a href="<?=base_url()?>home"><i class="fa fa-bar-chart"></i> EKG</a></li>

        <li id="m_ekg"><a href="<?=base_url()?>home"><i class="fa fa-bed"></i> Fisioterapi</a></li>

        <li id="m_ekg"><a href="<?=base_url()?>home"><i class="fa fa-tint"></i> Laboratorium</a></li>

        <li class="dropdown" id="m_ro">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-search"></i> Rontgen <span class="caret"></span></a>
          <ul class="dropdown-menu" role="menu">
            <li id="m_pasien"><a href="<?=base_url()?>home"> Thorak</a></li>
            <li id="m_dokter"><a href="<?=base_url()?>home"> Gigi</a></li>
          </ul>
        </li>

        <li id="m_treadmil"><a href="<?=base_url()?>home"><i class="fa fa-bug"></i> Treadmil</a></li>

        <li id="m_apotek"><a href="<?=base_url()?>home"><i class="fa fa-cart-plus"></i> Apotek</a></li>

      </ul>

      <ul class="nav navbar-nav navbar-right">
        <li><input type="hidden" class="form-control" value="<?= $this->session->userdata('id_user'); ?>" id="txtstatus"></li>
        <li><a href="<?=base_url()?>logout"><i class="fa fa-sign-out"></i> Logout</a></li>
      </ul>
    </div>
    </div>
  </nav>
</header>
