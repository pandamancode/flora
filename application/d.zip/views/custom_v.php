<div class='row'>
	<div class='col-md-12'>
		<div class="box box-primary">
			<div class="panel-heading">
				<i class='fa fa-shopping-cart fa-fw'></i> Order Custom <i class='fa fa-angle-right fa-fw'></i> Transaksi <i class='fa fa-angle-right fa-fw'></i><i id="nota_judul"></i>
				<a href="#" class='pull-right'><i class='fa fa-refresh fa-fw'></i> Refresh</a>
			</div>
			<div class="box box-body">
				<table class='table table-striped table-hover' id='TabelTransaksi'>
				<thead>
					<tr>
						<th width="5%">#</th>
						<th>Nama Pesanan</th>
						<th>Harga</th>
						<th width="10%">Qty</th>
						<th>Sub</th>
						<th width="5%"></th>
					</tr>
				</thead>
				<tbody id="data-result">

					
				</tbody>
				</table>
				
			</div>
		</div>
	</div>
</div>

<div id="tempat-modal"></div>

<script type="text/javascript">
	$('#custom').addClass('active');
</script>