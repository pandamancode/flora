<style>
    body {        
        background-image: url("<?=base_url('assets/images/bkgne.jpg')?>");
        background-size: 100%;        
        background-repeat: repeat-y;
        
    }
   #eyx_demo {
        background-image: url("<?=base_url('assets/images/bkg.png')?>");
        background-repeat: no-repeat;
        background-size: cover;
        opacity : 0.7;
        
        
    }
    </style>
  <div id="eyx_scr"></div>  
  <div class="container-fluid">
    <div class="media-center">
      <img src="<?php echo base_url();?>assets/dist/img/logo.png" class="img-rounded" alt="Cinque Terre" width="250">
      <br><small class="text-danger">kalo.my.id</small>
    </div>
    
    <div class="well" id="eyx_demo">      
        <h2 style="text-align: center;"><b>Praktik Klinik Keperawatan Suwanto</b></h2>
        <h2 style="text-align: center;">Jl. Soekarno Hatta  No 04. Dusun IV Desa Sribhawono, Kec. Bandar Sribhawono, Kab LamTim</h2>
    </div>
  </div>
<script type="text/javascript">
  $('#m_home').addClass('active');
</script>