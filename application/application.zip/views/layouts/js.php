<script src="<?php echo base_url()?>assets/plugins/jQuery/jQuery-2.1.3.min.js"></script>
<script src="<?php echo base_url()?>assets/plugins/jQuery/jquery.form.min.js"></script>
<script src="<?php echo base_url()?>assets/plugins/jQuery/jquery.preload.min.js"></script>
<script type="text/javascript" src="<?php echo base_url() ?>assets/plugins/datepicker/bootstrap-datepicker.js"></script>
<script src="<?php echo base_url()?>assets/bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
<script src="<?php echo base_url()?>assets/plugins/slimScroll/jquery.slimscroll.min.js" type="text/javascript"></script>
<script src="<?php echo base_url()?>assets/plugins/fastclick/fastclick.min.js"></script>
<script src="<?php echo base_url()?>assets/dist/js/app.min.js" type="text/javascript"></script>
<script src="<?php echo base_url()?>assets/dist/js/jquery.chained.min.js" type="text/javascript"></script>
<script src="<?php echo base_url();?>assets/plugins/datatables/jquery.dataTables.js"></script>
<script src="<?php echo base_url();?>assets/plugins/datatables/dataTables.bootstrap.js"></script>


<script type="text/javascript" src="<?php echo base_url() ?>assets/plugins/datepicker/bootstrap-datepicker.js"></script>
<script type="text/javascript" src="<?php echo base_url() ?>assets/plugins/select2/select2.full.min.js"></script>
<script type="text/javascript" src="<?php echo base_url() ?>assets/plugins/gritter/jquery.gritter.js"></script>

<script src="<?php echo base_url() ?>assets/highchart/highcharts.js"></script>
<script src="<?php echo base_url() ?>assets/highchart/highcharts-more.js"></script>
<script src="<?php echo base_url() ?>assets/highchart/modules/exporting.js"></script>

<script src="<?php echo base_url() ?>assets/JsBarcode.all.min.js"></script>
<script type="text/javascript" src="<?php echo base_url() ?>assets/plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js"></script>  